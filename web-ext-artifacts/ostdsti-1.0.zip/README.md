web-ext run --verbose
